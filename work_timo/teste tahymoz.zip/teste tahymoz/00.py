
arquivo = open("./texto.txt", "r", encoding="utf-8")
linhas = arquivo.readlines()

endereco = 0
atual = linhas[endereco].split(",")
texto_atual = atual[0]
endereco_a = int(atual[1])
endereco_b = int(atual[2])

while True:
    resposta = input(texto_atual)
    if (resposta == "A"):
        atual = linhas[endereco_a - 1]
        break
    elif (resposta == "B"):
        atual = linhas[endereco_b - 1]
        break
    else: 
        continue

texto_atual = atual.split(",")[0]
print(texto_atual)